package com.springmvc;

import com.springmvc.model.Address;
import com.springmvc.model.Employee;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import java.io.IOException;

@Controller
public class RequestDemoController {


    @ModelAttribute("OfficeAddress")
    public Address setAddress() {
        final Address address = new Address();
        address.setStreet("Vallavan Street");
        address.setCity("Chennai");
        return address;
    }


    @RequestMapping(value = "/post-demo", method = RequestMethod.POST)
    public void showRequestBodyDemo(@ModelAttribute final Employee employee) throws IOException {
        System.out.println("employee-------" + employee);
    }

    @RequestMapping(value = "/post-demo1", method = RequestMethod.POST)
    public void showRequestBodyDemo1(@RequestBody final Employee employee,
                                     @ModelAttribute("OfficeAddress") final Address address) {
        employee.setAddress(address);
        System.out.println("employee1-------" + employee);
    }

    @RequestMapping(value = "/post-demo2", method = RequestMethod.POST)
    public void showRequestBodyDemo2(@RequestBody final Employee employee) {
        System.out.println("employee2-------" + employee);
    }

    @ResponseBody
    @RequestMapping(value = "/post-demo3", method = RequestMethod.POST)
    public Address showRequestBodyDemo3(@RequestBody final Employee employee,
                                        @ModelAttribute("OfficeAddress") final Address address) {
        return address;
    }
}
