package com.springmvc;

class Employee{
        private Integer id;
        private String name;
        private String location;

         Employee(Integer id, String name, String location) {
            this.id = id;
            this.name = name;
            this.location = location;
        }

        public Integer getId() {
            return id;
        }

        public String getName() {
            return name;
        }

        public String getLocation() {
            return location;

        }

    @Override
    public String toString() {
        return "Employee{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", location='" + location + '\'' +
                '}';
    }
}