package com.springmvc;


import com.springmvc.model.Customer;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.context.ContextLoaderListener;

@Controller
public class FormDemoController {

    //http://localhost:8089/sample/customer
    @RequestMapping(value = "/customer", method = RequestMethod.GET)
    public String showCustomerDetailPage(){
        return "customer";
    }


    @RequestMapping(value = "/customer/get-by-name-and-phone", method = RequestMethod.GET)
    public String getCustomerByNameAndPhone(final Customer customer){
        System.out.println(" getCustomerByNameAndPhone------> "+customer);
        return "customer";
    }

    @RequestMapping(value = "/customer/save", method = RequestMethod.POST)
    public String saveCustomer(final Customer customer){
        System.out.println("saveCustomer-------->>>"+customer);
        return "customer";
    }


}
