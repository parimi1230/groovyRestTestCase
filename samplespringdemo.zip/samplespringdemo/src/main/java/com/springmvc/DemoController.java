package com.springmvc;


import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Controller
public class DemoController {


    @RequestMapping(value = "/employees/{myName}", method = RequestMethod.GET)
    public void doGet1(@PathVariable final String myName) {
        System.out.println("Do get 2" + myName);
    }

    @RequestMapping(value = "/do-post1", method = RequestMethod.POST)
    public void doPost1() throws IOException {
        System.out.println("Do post 1");
    }

    @RequestMapping(value = "/do-get-with-view", method = RequestMethod.GET)
    public ModelAndView doGetWithView(final ModelAndView modelAndView) {
        System.out.println("do get with view");
        modelAndView.setViewName("my-sample-home");
        return modelAndView;
    }


    @RequestMapping(value = "/do-get-with-view1", method = RequestMethod.GET)
    public void doGetWithView2(final ModelAndView modelAndView) {
        System.out.println("do get with view");
        modelAndView.setViewName("sample2");
    }


    public static void main(String[] args) {
        final Employee employee1 = new Employee(1, "Sai", "Nellore");
        final Employee employee2 = new Employee(1, "Venu", "Gach");
        final Employee employee3 = new Employee(1, "Ravi", "Santa");
        final Employee employee4 = new Employee(2, "Gavrav", "Chennai");

        final List<Employee> employees = Arrays.asList(employee1, employee2, employee3, employee4);

        final Map<Integer, List<Employee>> employeeMap = new HashMap<>();
        for(final Employee emp : employees){
            if(employeeMap.containsKey(emp.getId())){
                final List<Employee> employeesListInMap = employeeMap.get(emp.getId());
                employeesListInMap.add(emp);
            }else{
                final List<Employee> employeeList = new ArrayList<>();
                employeeList.add(emp);
                employeeMap.put(emp.getId(), employeeList);
            }
        }
        System.out.println(employeeMap);

    }
}
