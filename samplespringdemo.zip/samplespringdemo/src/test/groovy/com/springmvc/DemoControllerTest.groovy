package com.springmvc

import org.springframework.http.MediaType
import org.springframework.test.web.servlet.MockMvc
import org.springframework.test.web.servlet.setup.MockMvcBuilders
import spock.lang.Specification
import spock.lang.Subject

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post

class DemoControllerTest extends Specification {

    @Subject
    def DemoController demoController
    def MockMvc mockMvc;

    def setup() {
        demoController = new DemoController();
        mockMvc = MockMvcBuilders.standaloneSetup(demoController).build()
    }

    def "DoGet1"() {

        given:
        int i = 10
        final String test = "123456";
        when:
        def result = mockMvc.perform(post("/do-post1")
                .content(test)
                .contentType(MediaType.APPLICATION_JSON))

        then:
        1 == 1
    }
}
